const AlbumValidator = require('./validator');

module.exports = { AlbumValidator };
