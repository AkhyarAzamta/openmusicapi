const Joi = require('joi');
const ActitivityPayloadSchema = Joi.object();

module.exports = { ActitivityPayloadSchema };