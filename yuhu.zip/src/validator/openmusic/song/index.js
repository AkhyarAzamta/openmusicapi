const SongValidator = require('./validator');

module.exports = { SongValidator };
